print("Python has three numeric types: int, float, and complex")
myvalue=1
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the type of " + str(type(myvalue)))
myvalue=3.14
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the type of " + str(type(myvalue)))
myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the type of " + str(type(myvalue)))
